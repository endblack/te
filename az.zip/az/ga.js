ᨳ🍔•Figurinhas feita    
  pela : ᎧᎢ⍺kᎥᥒɦo᥉🌷      
  
ᨳ🚀 ໋• Nosso discord:   
 ⤷ bit.ly/3hUBBLN
 
 
 
 
 
 
 ᨳ🍔•Figurinhas feita\n  pela : ᎧᎢ⍺kᎥᥒɦo᥉🌷\n\nᨳ🚀 ໋• Nosso discord:\n ⤷ bit.ly/3hUBBLN